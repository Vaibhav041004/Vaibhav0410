# main.py
from chatbot import run_cli_chatbot

if __name__ == "__main__":
    run_cli_chatbot()